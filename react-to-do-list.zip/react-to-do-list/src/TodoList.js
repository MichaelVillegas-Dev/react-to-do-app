import React, { useState, useEffect } from 'react';
import { collection, addDoc, getDocs, updateDoc, deleteDoc, doc } from 'firebase/firestore';
import { db } from './firebase'; // adjust the path if needed

function TodoList() {
  const [tasks, setTasks] = useState([]);
  const [newTask, setNewTask] = useState('');
  const [isEditing, setIsEditing] = useState(false);
  const [currentTaskIndex, setCurrentTaskIndex] = useState(null);

  useEffect(() => {
    const fetchTasks = async () => {
      const tasksCollection = collection(db, 'tasks');
      const tasksSnapshot = await getDocs(tasksCollection);
      const tasksList = tasksSnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setTasks(tasksList);
    };

    fetchTasks();
  }, []);

  const handleAddTask = async () => {
    if (newTask.trim() !== '') {
      if (isEditing) {
        const taskDoc = doc(db, 'tasks', tasks[currentTaskIndex].id);
        await updateDoc(taskDoc, { text: newTask });
        setIsEditing(false);
        setCurrentTaskIndex(null);
      } else {
        await addDoc(collection(db, 'tasks'), { text: newTask, completed: false });
      }
      setNewTask('');
      const tasksCollection = collection(db, 'tasks');
      const tasksSnapshot = await getDocs(tasksCollection);
      const tasksList = tasksSnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setTasks(tasksList);
    }
  };

  const handleCompleteTask = async (index) => {
    const taskDoc = doc(db, 'tasks', tasks[index].id);
    await updateDoc(taskDoc, { completed: !tasks[index].completed });

    const tasksCollection = collection(db, 'tasks');
    const tasksSnapshot = await getDocs(tasksCollection);
    const tasksList = tasksSnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    setTasks(tasksList);
  };

  const handleDeleteTask = async (index) => {
    const taskDoc = doc(db, 'tasks', tasks[index].id);
    await deleteDoc(taskDoc);

    const tasksCollection = collection(db, 'tasks');
    const tasksSnapshot = await getDocs(tasksCollection);
    const tasksList = tasksSnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    setTasks(tasksList);
  };

  const handleEditTask = (index) => {
    setNewTask(tasks[index].text);
    setIsEditing(true);
    setCurrentTaskIndex(index);
  };

  return (
    <div className="max-w-md mx-auto p-4">
      <h1 className="text-2xl font-bold mb-4 text-center">To-Do List</h1>
      <div className="flex mb-4">
        <input
          type="text"
          value={newTask}
          onChange={(e) => setNewTask(e.target.value)}
          placeholder="Add a new task"
          className="flex-grow p-2 border rounded"
        />
        <button
          onClick={handleAddTask}
          className="ml-2 px-4 py-2 bg-blue-500 text-white rounded"
        >
          {isEditing ? 'Update Task' : 'Add Task'}
        </button>
      </div>
      <ul className="list-none p-0">
        {tasks.length === 0 ? (
          <p>No tasks available</p>
        ) : (
          tasks.map((task, index) => (
            <li
              key={task.id}
              className={`flex justify-between items-center p-4 mb-4 bg-white rounded shadow ${
                task.completed ? 'line-through text-gray-500' : ''
              }`}
            >
              <span onClick={() => handleCompleteTask(index)} className="cursor-pointer">
                {task.text}
              </span>
              <div className="flex space-x-2">
                <button
                  onClick={() => handleEditTask(index)}
                  className="bg-yellow-500 text-white px-2 py-1 rounded"
                >
                  Edit
                </button>
                <button
                  onClick={() => handleDeleteTask(index)}
                  className="bg-red-500 text-white px-2 py-1 rounded"
                >
                  Delete
                </button>
              </div>
            </li>
          ))
        )}
      </ul>
    </div>
  );
}

export default TodoList;
