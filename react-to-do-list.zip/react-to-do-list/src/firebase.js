import { initializeApp } from 'firebase/app';
import { getFirestore } from 'firebase/firestore';

const firebaseConfig = {
    apiKey: "AIzaSyA2LtXPtBWm602ttUi5hMqV1CXu4lFyPzE",
    authDomain: "alertme-5abba.firebaseapp.com",
    projectId: "alertme-5abba",
    storageBucket: "alertme-5abba.appspot.com",
    messagingSenderId: "207233739051",
    appId: "1:207233739051:web:cb1190986617531fb7fd6e",
    measurementId: "G-P66ZTF0PRT"
  };


const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

export { db };
